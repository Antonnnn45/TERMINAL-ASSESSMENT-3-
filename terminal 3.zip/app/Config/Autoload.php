<?php

namespace Config;

use CodeIgniter\Config\AutoloadConfig;

class Autoload extends AutoloadConfig
{
    public $psr4 = [
        APP_NAMESPACE => APPPATH, // 'App' => APPPATH
    ];

    public $classmap = [];

    public $files = [];

    public $helpers = [
        'form',
        'auth' // ✅ This line loads app/Helpers/auth_helper.php automatically
    ];
}
