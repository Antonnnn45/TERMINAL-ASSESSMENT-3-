<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Home::index');

// Category routes
$routes->get('categories', 'CategoryController::index');
$routes->get('categories/create', 'CategoryController::create');
$routes->post('categories/store', 'CategoryController::store');
$routes->get('categories/edit/(:num)', 'CategoryController::edit/$1');
$routes->post('categories/update/(:num)', 'CategoryController::update/$1');
$routes->get('categories/delete/(:num)', 'CategoryController::delete/$1');

// Product routes
$routes->get('products', 'ProductController::index');
$routes->get('products/create', 'ProductController::create');
$routes->post('products/store', 'ProductController::store');
$routes->get('products/edit/(:num)', 'ProductController::edit/$1');
$routes->post('products/update/(:num)', 'ProductController::update/$1');
$routes->get('products/delete/(:num)', 'ProductController::delete/$1');

// Authentication routes
$routes->get('login', 'AuthController::login');
$routes->post('login', 'AuthController::process');
$routes->get('logout', 'AuthController::logout');
