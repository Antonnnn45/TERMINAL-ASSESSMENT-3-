<?php

namespace App\Controllers;

use App\Models\ProductModel;
use App\Models\CategoryModel;
use CodeIgniter\Controller;

class ProductController extends Controller
{
    protected $productModel;
    protected $categoryModel;
    protected $helpers = ['form'];

    public function __construct()
    {
        $this->productModel = new ProductModel();
        $this->categoryModel = new CategoryModel();
    }

    // List all products with search & filter + caching
    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $search = $this->request->getGet('search');
        $categoryFilter = $this->request->getGet('category_id');

        $cacheKey = 'products_' . md5($search . '_' . $categoryFilter);
        $cache = \Config\Services::cache();

        $data = $cache->get($cacheKey);
        if (!$data) {
            $builder = $this->productModel->withCategory();

            if ($search) {
                $builder->like('products.name', $search);
            }

            if ($categoryFilter) {
                $builder->where('products.category_id', $categoryFilter);
            }

            $data['products'] = $builder->findAll();
            $data['categories'] = $this->categoryModel->findAll();
            $data['search'] = $search;
            $data['category_id'] = $categoryFilter;

            $cache->save($cacheKey, $data, 60); // Cache for 60 seconds
        }

        return view('products/index', $data);
    }

    // Show create form
    public function create()
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to('/login');
        }

        $data['categories'] = $this->categoryModel->findAll();
        return view('products/create', $data);
    }

    // Store new product with image upload + cache clear
    public function store()
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to('/login');
        }

        $validation = \Config\Services::validation();

        $rules = [
            'name'           => 'required',
            'category_id'    => 'required|integer',
            'price'          => 'required|decimal',
            'stock_quantity' => 'required|integer',
            'product_image'  => 'uploaded[product_image]|is_image[product_image]|max_size[product_image,2048]',
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $image = $this->request->getFile('product_image');
        $imageName = $image->getRandomName();
        $image->move('uploads', $imageName);

        $this->productModel->save([
            'name'           => $this->request->getPost('name'),
            'category_id'    => $this->request->getPost('category_id'),
            'price'          => $this->request->getPost('price'),
            'stock_quantity' => $this->request->getPost('stock_quantity'),
            'product_image'  => $imageName,
        ]);

        \Config\Services::cache()->clean(); // clear all cache

        session()->setFlashdata('success', 'Product added with image!');
        return redirect()->to('/products');
    }

    // Show edit form
    public function edit($id)
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to('/login');
        }

        $data['product'] = $this->productModel->find($id);
        $data['categories'] = $this->categoryModel->findAll();
        return view('products/edit', $data);
    }

    // Update product with optional image upload + cache clear
    public function update($id)
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to('/login');
        }

        $validation = \Config\Services::validation();

        $rules = [
            'name'           => 'required',
            'category_id'    => 'required|integer',
            'price'          => 'required|decimal',
            'stock_quantity' => 'required|integer|min_length[1]',
            'product_image'  => 'if_exist|is_image[product_image]|max_size[product_image,2048]'
        ];

        if (!$this->validate($rules)) {
            return redirect()->back()->withInput()->with('errors', $validation->getErrors());
        }

        $data = [
            'name'           => $this->request->getPost('name'),
            'category_id'    => $this->request->getPost('category_id'),
            'price'          => $this->request->getPost('price'),
            'stock_quantity' => $this->request->getPost('stock_quantity'),
        ];

        $image = $this->request->getFile('product_image');
        if ($image && $image->isValid() && !$image->hasMoved()) {
            $newName = $image->getRandomName();
            $image->move('uploads', $newName);
            $data['product_image'] = $newName;
        }

        $this->productModel->update($id, $data);

        \Config\Services::cache()->clean(); // clear all cache

        session()->setFlashdata('success', 'Product updated successfully!');
        return redirect()->to('/products');
    }

    // Delete product + cache clear
    public function delete($id)
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to('/login');
        }

        $this->productModel->delete($id);

        \Config\Services::cache()->clean(); // clear all cache

        session()->setFlashdata('success', 'Product deleted successfully!');
        return redirect()->to('/products');
    }
}
