<?php

namespace App\Controllers;

use App\Models\CategoryModel;
use CodeIgniter\Controller;

class CategoryController extends Controller
{
    protected $categoryModel;
    protected $helpers = ['form'];

    public function __construct()
    {
        $this->categoryModel = new CategoryModel();
    }

    // List all categories
    public function index()
    {
        if (!session()->get('logged_in')) {
            return redirect()->to('/login');
        }

        $data['categories'] = $this->categoryModel->findAll();
        return view('categories/index', $data);
    }

    // Show create form
    public function create()
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to('/login');
        }

        return view('categories/create');
    }

    // Store new category
    public function store()
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to('/login');
        }

        $this->categoryModel->save([
            'name' => $this->request->getPost('name')
        ]);

        session()->setFlashdata('success', 'Category added successfully!');
        return redirect()->to('/categories');
    }

    // Show edit form
    public function edit($id)
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to('/login');
        }

        $data['category'] = $this->categoryModel->find($id);
        return view('categories/edit', $data);
    }

    // Update category
    public function update($id)
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to('/login');
        }

        $this->categoryModel->update($id, [
            'name' => $this->request->getPost('name')
        ]);

        session()->setFlashdata('success', 'Category updated successfully!');
        return redirect()->to('/categories');
    }

    // Delete category
    public function delete($id)
    {
        if (!session()->get('logged_in') || session()->get('role') !== 'admin') {
            return redirect()->to('/login');
        }

        $this->categoryModel->delete($id);
        session()->setFlashdata('success', 'Category deleted successfully!');
        return redirect()->to('/categories');
    }
}
