<?php

namespace App\Controllers;

use App\Models\UserModel;
use CodeIgniter\Controller;

class AuthController extends Controller
{
    protected $userModel;
    protected $helpers = ['form'];

    public function __construct()
    {
        $this->userModel = new UserModel();
    }

    public function login()
    {
        return view('auth/login');
    }

    public function process()
    {
        $session = session();

        $username = $this->request->getPost('username');
        $password = $this->request->getPost('password');

        $user = $this->userModel->where('username', $username)->first();

        if (!$user || !password_verify($password, $user['password'])) {
            return redirect()->back()->with('error', 'Invalid credentials');
        }

        // ✅ Set role in session
        $session->set([
            'logged_in' => true,
            'username'  => $user['username'],
            'role'      => $user['role'], // example: 'admin' or 'staff'
        ]);

        return redirect()->to('/products');
    }

    public function logout()
    {
        session()->destroy();
        return redirect()->to('/login');
    }
}
