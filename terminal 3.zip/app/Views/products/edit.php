<!DOCTYPE html>
<html>
<head>
    <title>Edit Product</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="p-4">
<div class="container">
    <h2>Edit Product</h2>

    <?php if (session()->get('errors')): ?>
        <div class="alert alert-danger">
            <ul class="mb-0">
                <?php foreach (session()->get('errors') as $error): ?>
                    <li><?= esc($error) ?></li>
                <?php endforeach ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="post" action="/products/update/<?= $product['id'] ?>" enctype="multipart/form-data">
        <div class="mb-3">
            <label>Product Name</label>
            <input type="text" name="name" class="form-control" value="<?= old('name', $product['name']) ?>" required>
        </div>

        <div class="mb-3">
            <label>Category</label>
            <select name="category_id" class="form-select" required>
                <option value="">-- Select Category --</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?= $cat['id'] ?>"
                        <?= old('category_id', $product['category_id']) == $cat['id'] ? 'selected' : '' ?>>
                        <?= esc($cat['name']) ?>
                    </option>
                <?php endforeach ?>
            </select>
        </div>

        <div class="mb-3">
            <label>Price</label>
            <input type="number" step="0.01" name="price" class="form-control"
                   value="<?= old('price', $product['price']) ?>" required>
        </div>

        <div class="mb-3">
            <label>Stock Quantity</label>
            <input type="number" name="stock_quantity" class="form-control"
                   value="<?= old('stock_quantity', $product['stock_quantity']) ?>" required>
        </div>

        <div class="mb-3">
            <label>Change Image (optional)</label>
            <input type="file" name="product_image" class="form-control">
            <?php if (!empty($product['product_image'])): ?>
                <img src="/uploads/<?= esc($product['product_image']) ?>" width="100" class="mt-2">
            <?php endif ?>
        </div>

        <button type="submit" class="btn btn-success">Update</button>
        <a href="/products" class="btn btn-secondary">Back</a>
    </form>
</div>
</body>
</html>
