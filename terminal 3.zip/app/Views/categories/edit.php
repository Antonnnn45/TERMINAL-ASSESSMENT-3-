<!DOCTYPE html>
<html>
<head>
    <title>Edit Category</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="p-4">
    <div class="container">
        <h2>Edit Category</h2>
        <form method="post" action="/categories/update/<?= $category['id'] ?>">
            <div class="mb-3">
                <label for="name" class="form-label">Category Name</label>
                <input type="text" class="form-control" name="name" value="<?= esc($category['name']) ?>" required>
            </div>
            <button type="submit" class="btn btn-success">Update</button>
            <a href="/categories" class="btn btn-secondary">Back</a>
        </form>
    </div>
</body>
</html>
