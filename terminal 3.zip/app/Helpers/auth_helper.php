<?php

if (!function_exists('is_logged_in')) {
    function is_logged_in(): bool
    {
        return session()->get('logged_in') === true;
    }
}

if (!function_exists('is_admin')) {
    function is_admin(): bool
    {
        return session()->get('role') === 'admin';
    }
}

if (!function_exists('has_role')) {
    function has_role($role): bool
    {
        return session()->get('role') === $role;
    }
}

if (!function_exists('get_user_role')) {
    function get_user_role(): string
    {
        return session()->get('role') ?? '';
    }
}

if (!function_exists('get_username')) {
    function get_username(): string
    {
        return session()->get('username') ?? 'Guest';
    }
}
