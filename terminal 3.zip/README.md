# Inventory Management System - Terminal Assessment 3

## 🔑 Default Login
- **Username:** admin
- **Password:** admin123

## 🚀 Features
- Product and category CRUD
- Image upload with validation
- Search and category filter
- Flash messages for actions
- Basic authentication system

## 🔒 Security
- CSRF protection enabled
- Form input validation
- File size/type checking for uploads

## 🗂 Modules
- Products
- Categories
- User login/logout

## 🛠 Setup Instructions
1. Clone/download the project folder.
2. Import the provided `.sql` file into your MySQL (e.g., via phpMyAdmin).
3. Configure your database in `.env` or `app/Config/Database.php`.
4. Run:
    ```bash
    php spark migrate
    ```
5. Start the app:
    ```bash
    php spark serve
    ```

6. Access via:  
   `http://localhost:8080/login`

## 🌐 Deployment Notes
- Works locally on `XAMPP` or `MAMP`.
- Upload folder must be writable for image uploads (`/public/uploads`).
- If deploying online (000webhost/InfinityFree), update base URL and test image uploads.

